/* Kin-Aesthetics — minor interactions */

// Scroll reveal
const revealEls = document.querySelectorAll(
  ".display, .h2, .lede, .svc, .pill, .faq-item, .stat, .beliefs-list li, .r-row, .photo-frame, .photo-meta, .contact-card, .about-card, .diff-card, .eyebrow, .hero-stats"
);
revealEls.forEach((el) => el.classList.add("reveal"));

const io = new IntersectionObserver(
  (entries) => {
    entries.forEach((e) => {
      if (e.isIntersecting) {
        e.target.classList.add("in");
        io.unobserve(e.target);
      }
    });
  },
  { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
);
revealEls.forEach((el) => io.observe(el));

// Single-open accordion behaviour (FAQ)
const faqs = document.querySelectorAll(".faq-item");
faqs.forEach((item) => {
  item.addEventListener("toggle", () => {
    if (item.open) {
      faqs.forEach((other) => {
        if (other !== item) other.open = false;
      });
    }
  });
});

// Contact form — mock submit
const form = document.getElementById("inquiryForm");
const note = document.getElementById("formNote");
if (form) {
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const data = new FormData(form);
    const first = (data.get("first") || "").toString().trim();
    const email = (data.get("email") || "").toString().trim();
    if (!first || !email) {
      note.textContent = "A first name and email is plenty to start.";
      note.style.color = "#B45A3C";
      return;
    }
    note.style.color = "";
    note.textContent =
      "Thanks, " + first + " — we'll be in touch within 2 business days.";
    form.reset();
  });
}

// Header shadow on scroll
const header = document.querySelector(".site-header");
const updateHeader = () => {
  if (window.scrollY > 8) {
    header.style.boxShadow = "0 1px 0 rgba(40,30,15,.06), 0 20px 40px -30px rgba(40,30,15,.18)";
  } else {
    header.style.boxShadow = "none";
  }
};
updateHeader();
window.addEventListener("scroll", updateHeader, { passive: true });
